"""
totp_module.py
A minimal, dependency-free TOTP implementation (RFC 6238 compatible).
Functions:
 - generate_base32_secret(length=16)
 - get_totp_token(secret, digits=6, time_step=30, for_time=None)
 - verify_totp(token, secret, digits=6, time_step=30, allowed_drift=1)
 - build_otpauth_url(secret, account_name, issuer)
"""

import base64, hmac, hashlib, time, struct, secrets, urllib.parse

def generate_base32_secret(length=16):
    """Return a random base32 secret (compatible with Google Authenticator)."""
    # generate random bytes then encode as base32 without padding
    raw = secrets.token_bytes(length)
    return base64.b32encode(raw).decode('utf-8').replace('=', '')

def _int_to_bytes(i):
    return struct.pack(">Q", i)

def _dynamic_truncate(hmac_digest):
    offset = hmac_digest[-1] & 0x0F
    code = ((hmac_digest[offset] & 0x7f) << 24) | \
           ((hmac_digest[offset+1] & 0xff) << 16) | \
           ((hmac_digest[offset+2] & 0xff) << 8) | \
           (hmac_digest[offset+3] & 0xff)
    return code

def get_totp_token(secret, digits=6, time_step=30, for_time=None):
    """
    Generate a TOTP code for given secret.
    secret: base32 encoded secret (no padding required)
    for_time: epoch seconds to use instead of now
    """
    if for_time is None:
        for_time = int(time.time())
    key = base64.b32decode(secret.upper()+('=' * ((8 - len(secret) % 8) % 8)))
    counter = int(for_time // time_step)
    counter_bytes = _int_to_bytes(counter)
    hmac_digest = hmac.new(key, counter_bytes, hashlib.sha1).digest()
    code_int = _dynamic_truncate(hmac_digest)
    return str(code_int % (10 ** digits)).zfill(digits)

def verify_totp(token, secret, digits=6, time_step=30, allowed_drift=1, for_time=None):
    """
    Verify a TOTP token allowing +/- allowed_drift time-steps for clock skew.
    Returns True if valid.
    """
    if for_time is None:
        for_time = int(time.time())
    token = str(token).zfill(digits)
    # check time steps in window
    for drift in range(-allowed_drift, allowed_drift+1):
        t = for_time + (drift * time_step)
        if get_totp_token(secret, digits=digits, time_step=time_step, for_time=t) == token:
            return True
    return False

def build_otpauth_url(secret, account_name, issuer=None, digits=6, time_step=30):
    """
    Build an otpauth:// URL that apps like Google Authenticator understand.
    Example:
      otpauth://totp/Issuer:alice@example.com?secret=BASE32&issuer=Issuer&digits=6&period=30
    """
    label = account_name if issuer is None else f"{issuer}:{account_name}"
    params = {'secret': secret, 'digits': str(digits), 'period': str(time_step)}
    if issuer:
        params['issuer'] = issuer
    qs = urllib.parse.urlencode(params)
    return f"otpauth://totp/{urllib.parse.quote(label)}?{qs}"
