"""
app.py - A minimal Flask app demonstrating Two-Factor Authentication (TOTP).
Features:
 - Register user (stores username + password hash + 2FA secret and enabled flag)
 - Login (password check; if 2FA enabled, asks for TOTP)
 - Enable/Disable 2FA (generates secret and shows otpauth URL)
This is a simple example for learning and should NOT be used as-is in production.
"""

from flask import Flask, request, session, redirect, url_for, render_template_string, flash
import sqlite3, hashlib, os
from totp_module import generate_base32_secret, get_totp_token, verify_totp, build_otpauth_url

DB = 'users.db'
SECRET_KEY = os.environ.get('FLASK_SECRET', 'dev_secret_change_me')

app = Flask(__name__)
app.secret_key = SECRET_KEY

# --- simple DB helpers ---
def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE,
                    password_hash TEXT,
                    totp_secret TEXT,
                    totp_enabled INTEGER DEFAULT 0
                )""")
    conn.commit()
    conn.close()

def get_user(username):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('SELECT id, username, password_hash, totp_secret, totp_enabled FROM users WHERE username=?', (username,))
    row = c.fetchone()
    conn.close()
    if row:
        return dict(id=row[0], username=row[1], password_hash=row[2], totp_secret=row[3], totp_enabled=bool(row[4]))
    return None

def create_user(username, password):
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
    conn.commit()
    conn.close()

def set_totp_for_user(username, secret, enabled):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('UPDATE users SET totp_secret=?, totp_enabled=? WHERE username=?', (secret, int(enabled), username))
    conn.commit()
    conn.close()

# --- templates (minimal inline templates for demo) ---
tpl_home = """
<h2>Mini 2FA Demo</h2>
<p><a href='/register'>Register</a> | <a href='/login'>Login</a> | <a href='/profile'>Profile</a></p>
"""

tpl_register = """
<h2>Register</h2>
<form method='post'>
  Username: <input name='username'><br>
  Password: <input type='password' name='password'><br>
  <button type='submit'>Register</button>
</form>
<p><a href='/'>Home</a></p>
"""

tpl_login = """
<h2>Login</h2>
<form method='post'>
  Username: <input name='username'><br>
  Password: <input type='password' name='password'><br>
  <button type='submit'>Login</button>
</form>
<p><a href='/'>Home</a></p>
"""

tpl_2fa = """
<h2>Enter 2FA Code</h2>
<form method='post'>
  Code: <input name='code'><br>
  <button type='submit'>Verify</button>
</form>
"""

tpl_profile = """
<h2>Profile: {{username}}</h2>
{% if totp_enabled %}
  <p>Two-Factor Authentication is <strong>ENABLED</strong>.</p>
  <form method='post' action='/disable_2fa'><button>Disable 2FA</button></form>
{% else %}
  <p>Two-Factor Authentication is <strong>DISABLED</strong>.</p>
  <form method='post' action='/enable_2fa'><button>Enable 2FA</button></form>
{% endif %}
<p><a href='/'>Home</a></p>
"""

tpl_enable = """
<h2>Enable 2FA</h2>
<p>Scan this URL in your authenticator app (or enter the secret manually):</p>
<p><strong>otpauth URL:</strong> {{otpauth}}</p>
<p><strong>Secret (base32):</strong> {{secret}}</p>
<p>After adding, submit the current code to confirm:</p>
<form method='post'>
  Code: <input name='code'><br>
  <button type='submit'>Enable</button>
</form>
"""

# --- routes ---
@app.route('/')
def home():
    return render_template_string(tpl_home)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        u = request.form['username'].strip()
        p = request.form['password']
        if not u or not p:
            flash('missing fields')
        else:
            if get_user(u):
                flash('user exists')
            else:
                create_user(u, p)
                flash('registered')
                return redirect(url_for('login'))
    return render_template_string(tpl_register)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = request.form['username'].strip()
        p = request.form['password']
        user = get_user(u)
        if not user:
            flash('invalid')
        else:
            if hashlib.sha256(p.encode()).hexdigest() != user['password_hash']:
                flash('invalid')
            else:
                session['username'] = u
                # if user has totp enabled -> ask for code
                if user['totp_enabled']:
                    session['awaiting_2fa'] = True
                    return redirect(url_for('two_factor'))
                flash('logged in')
                return redirect(url_for('profile'))
    return render_template_string(tpl_login)

@app.route('/two_factor', methods=['GET','POST'])
def two_factor():
    if 'username' not in session or not session.get('awaiting_2fa'):
        return redirect(url_for('login'))
    user = get_user(session['username'])
    if request.method == 'POST':
        code = request.form['code'].strip()
        if verify_totp(code, user['totp_secret']):
            session.pop('awaiting_2fa', None)
            flash('2FA success, logged in')
            return redirect(url_for('profile'))
        else:
            flash('Invalid code')
    return render_template_string(tpl_2fa)

@app.route('/profile')
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))
    user = get_user(session['username'])
    return render_template_string(tpl_profile, username=user['username'], totp_enabled=user['totp_enabled'])

@app.route('/enable_2fa', methods=['GET','POST'])
def enable_2fa():
    if 'username' not in session:
        return redirect(url_for('login'))
    user = get_user(session['username'])
    # generate a secret and show otpauth (in real app store after verify)
    if request.method == 'GET':
        secret = generate_base32_secret(10)
        otpauth = build_otpauth_url(secret, user['username'], issuer='DemoApp')
        session['pending_2fa_secret'] = secret
        return render_template_string(tpl_enable, otpauth=otpauth, secret=secret)
    else:
        code = request.form['code'].strip()
        secret = session.get('pending_2fa_secret')
        if not secret:
            flash('no secret in session, try again')
            return redirect(url_for('enable_2fa'))
        if verify_totp(code, secret):
            set_totp_for_user(user['username'], secret, True)
            session.pop('pending_2fa_secret', None)
            flash('2FA enabled')
            return redirect(url_for('profile'))
        else:
            flash('Invalid code, not enabled')
            return redirect(url_for('enable_2fa'))

@app.route('/disable_2fa', methods=['POST'])
def disable_2fa():
    if 'username' not in session:
        return redirect(url_for('login'))
    set_totp_for_user(session['username'], None, False)
    flash('2FA disabled')
    return redirect(url_for('profile'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)


#pip install Flask
#python demo_totp.py
#python app.py