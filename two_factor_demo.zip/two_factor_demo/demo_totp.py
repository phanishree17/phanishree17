"""
demo_totp.py - CLI demo that shows TOTP generation and verification using totp_module.py
This runs without any external dependencies.
"""
from totp_module import generate_base32_secret, get_totp_token, verify_totp, build_otpauth_url
import time

print("TWO-FACTOR AUTHENTICATION DEMO (TOTP)")
secret = generate_base32_secret(10)
print("Generated base32 secret:", secret)
print("otpauth URL (scan with Authenticator app):")
print(build_otpauth_url(secret, "alice@example.com", issuer="DemoApp"))
print()

code = get_totp_token(secret)
print("Current OTP code:", code)
print("Verifying immediately:", verify_totp(code, secret))
time.sleep(1)
print("Verifying with wrong code '123456':", verify_totp('123456', secret))
# show drift: simulate code for next period
future_time = int(time.time()) + 30
future_code = get_totp_token(secret, for_time=future_time)
print("Future code (in +30s):", future_code)
print("Verify future code NOW with allowed_drift=1:", verify_totp(future_code, secret, allowed_drift=1))
print("Verify future code NOW with allowed_drift=0:", verify_totp(future_code, secret, allowed_drift=0))
