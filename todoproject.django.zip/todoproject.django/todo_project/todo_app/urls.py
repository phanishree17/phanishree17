from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("add/", views.add_task, name="add"),
    path("completed/", views.completed, name="completed"),
    path("trash/", views.trash, name="trash"),
    path("complete/<int:pk>/", views.mark_complete, name="complete"),
    path("delete/<int:pk>/", views.soft_delete, name="delete"),
    path("trash/delete/<int:pk>/", views.delete_forever, name="delete_forever"),
    path("delete_all/", views.delete_all, name="delete_all"),
    path("complete_all/", views.complete_all, name="complete_all"),
    path("trash/", views.trash, name="trash"),
    path("delete/<int:pk>/", views.soft_delete, name="delete"),
    path("delete-forever/<int:pk>/", views.delete_forever, name="delete_forever"),
    path("update/<int:pk>/", views.update_task, name="update"),
    path("about/", views.about, name="about"),
    path("restore/<int:pk>/", views.restore_task, name="restore"),




]
