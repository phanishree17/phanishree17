from django.apps import AppConfig


class TodoAppConfig(AppConfig):
    name = 'todo_app'
