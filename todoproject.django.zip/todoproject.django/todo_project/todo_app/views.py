from django.shortcuts import render, redirect, get_object_or_404
from .models import Task

def home(request):
    tasks = Task.objects.filter(completed=False, is_deleted=False)
    return render(request, "home.html", {"tasks": tasks})

def completed(request):
    tasks = Task.objects.filter(completed=True, is_deleted=False)
    return render(request, "completed.html", {"tasks": tasks})

def trash(request):
    tasks = Task.objects.filter(is_deleted=True)
    return render(request, "trash.html", {"tasks": tasks})

def add_task(request):
    if request.method == "POST":
        title = request.POST.get("title")
        desc = request.POST.get("description")
        Task.objects.create(title=title, description=desc)
        return redirect("home")
    return render(request, "add.html")

def mark_complete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.completed = True
    task.save()
    return redirect("home")

def soft_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.is_deleted = True
    task.save()
    return redirect("home")

def delete_forever(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.delete()
    return redirect("trash")

def delete_all(request):
    Task.objects.all().delete()
    return redirect("home")

def complete_all(request):
    Task.objects.filter(completed=False, is_deleted=False).update(completed=True)
    return redirect("home")
def home(request):
    tasks = Task.objects.filter(is_deleted=False)
    return render(request, "home.html", {"tasks": tasks})


def soft_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.is_deleted = True
    task.save()
    return redirect("home")


def trash(request):
    tasks = Task.objects.filter(is_deleted=True)
    return render(request, "trash.html", {"tasks": tasks})


def delete_forever(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.delete()
    return redirect("trash")

def update_task(request, pk):
    task = get_object_or_404(Task, pk=pk)

    if request.method == "POST":
        task.title = request.POST.get("title")
        task.description = request.POST.get("description")
        task.save()
        return redirect("home")

    return render(request, "update.html", {"task": task})
def about(request):
    return render(request, "about.html")

def restore_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.is_deleted = False
    task.save()
    return redirect("trash")