import customtkinter as ctk
import sqlite3
from tkinter import ttk, messagebox

# --------- Database Setup ----------
def connect_db():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            roll INTEGER PRIMARY KEY,
            name TEXT,
            course TEXT,
            fee INTEGER
        )
    """)
    conn.commit()
    conn.close()

connect_db()

# --------- Functions ----------
def add_student():
    if roll_var.get() == "" or name_var.get() == "":
        messagebox.showerror("Error", "All fields are required!")
        return

    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO students VALUES (?, ?, ?, ?)",
                       (roll_var.get(), name_var.get(), course_var.get(), fee_var.get()))
        conn.commit()
        messagebox.showinfo("Success", "Student added")
        fetch_students()
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Roll No already exists!")
    conn.close()


def fetch_students():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()

    for item in student_table.get_children():
        student_table.delete(item)

    for row in rows:
        student_table.insert("", "end", values=row)

    conn.close()


def get_data(event):
    selected = student_table.focus()
    data = student_table.item(selected)["values"]
    if data:
        roll_var.set(data[0])
        name_var.set(data[1])
        course_var.set(data[2])
        fee_var.set(data[3])


def update_student():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE students 
        SET name=?, course=?, fee=? 
        WHERE roll=?
    """, (name_var.get(), course_var.get(), fee_var.get(), roll_var.get()))
    conn.commit()
    conn.close()
    messagebox.showinfo("Updated", "Student updated")
    fetch_students()


def delete_student():
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE roll=?", (roll_var.get(),))
    conn.commit()
    conn.close()
    messagebox.showinfo("Deleted", "Student deleted")
    fetch_students()


def clear_fields():
    roll_var.set("")
    name_var.set("")
    course_var.set("")
    fee_var.set("")


# --------- UI Setup ----------
ctk.set_appearance_mode("dark")  # DARK THEME
ctk.set_default_color_theme("blue")  # Accent color

app = ctk.CTk()
app.title("Student Management System - Dark Theme")
app.geometry("900x550")


title = ctk.CTkLabel(app, text="Student Management System",
                      font=("Arial", 28, "bold"))
title.pack(pady=10)


# --- Input Frame ---
frame = ctk.CTkFrame(app, corner_radius=20)
frame.pack(pady=10)


roll_var = ctk.StringVar()
name_var = ctk.StringVar()
course_var = ctk.StringVar()
fee_var = ctk.StringVar()

ctk.CTkLabel(frame, text="Roll No:", font=("Arial", 15)).grid(row=0, column=0, padx=15, pady=10)
ctk.CTkEntry(frame, textvariable=roll_var, width=200).grid(row=0, column=1, padx=10)

ctk.CTkLabel(frame, text="Name:", font=("Arial", 15)).grid(row=1, column=0, padx=15, pady=10)
ctk.CTkEntry(frame, textvariable=name_var, width=200).grid(row=1, column=1, padx=10)

ctk.CTkLabel(frame, text="Course:", font=("Arial", 15)).grid(row=2, column=0, padx=15, pady=10)
ctk.CTkEntry(frame, textvariable=course_var, width=200).grid(row=2, column=1, padx=10)

ctk.CTkLabel(frame, text="Fees:", font=("Arial", 15)).grid(row=3, column=0, padx=15, pady=10)
ctk.CTkEntry(frame, textvariable=fee_var, width=200).grid(row=3, column=1, padx=10)


# --- Button Row (Rounded Buttons) ---
button_frame = ctk.CTkFrame(app, corner_radius=20)
button_frame.pack(pady=10)

ctk.CTkButton(button_frame, text="Add", width=120, height=40, corner_radius=20,
              command=add_student).grid(row=0, column=0, padx=20)

ctk.CTkButton(button_frame, text="Update", width=120, height=40, corner_radius=20,
              command=update_student).grid(row=0, column=1, padx=20)

ctk.CTkButton(button_frame, text="Delete", width=120, height=40, corner_radius=20,
              command=delete_student).grid(row=0, column=2, padx=20)

ctk.CTkButton(button_frame, text="Clear", width=120, height=40, corner_radius=20,
              command=clear_fields).grid(row=0, column=3, padx=20)


# --- Student Table ---
table_frame = ctk.CTkFrame(app)
table_frame.pack(fill="both", expand=True, pady=10)

columns = ("Roll", "Name", "Course", "Fees")
student_table = ttk.Treeview(table_frame, columns=columns, show="headings", height=8)

for col in columns:
    student_table.heading(col, text=col)
    student_table.column(col, width=150)

student_table.pack(fill="both", expand=True)
student_table.bind("<ButtonRelease-1>", get_data)

fetch_students()

app.mainloop()

#cd C:\Users\Subramanya\Desktop

#python student_management_dark.py