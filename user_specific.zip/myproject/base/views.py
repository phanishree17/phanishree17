from django.shortcuts import render,redirect
from .models import TaskModel
from django.db.models import Q
# Create your views here.
def home(request):
    if 'q' in request.GET:
        q = request.GET['q']
        all_data = TaskModel.objects.filter(Q(title__icontains=q) & Q(is_delete = False) & Q(host = request.user) | Q(desc__icontains=q) & Q(is_delete = False) & Q(host = request.user))
    else:
        all_data = TaskModel.objects.filter(Q(is_delete=False) & Q(host = request.user) )
    return render(request,'home.html',{'all_data':all_data})


def add(request):
    if request.method == 'POST':
        title = request.POST['title']
        desc = request.POST['desc']
        TaskModel.objects.create(
            title=title,
            desc=desc,
            host = request.user
        )
    return render(request,'add.html')

def complete(request):
    return render(request,'complete.html')

def trash(request):
    data = TaskModel.objects.filter(Q(is_delete = True)  & Q(host = request.user))
    return render(request,'trash.html',{'data':data})

def about(request):
    return render(request,'about.html')

def delete_(request,pk):
    a = TaskModel.objects.get(id=pk)
    a.is_delete = True
    a.save()
    return redirect('home')

def restore(reqeust,pk):
    a = TaskModel.objects.get(id=pk)
    a.is_delete = False
    a.save()
    return redirect('home')