from django.urls import path
from .views import *

urlpatterns = [
    path('',home,name='home'),
    path('add/',add,name='add'),
    path('complete/',complete,name='complete'),
    path('tash/',trash,name='trash'),
    path('about/',about,name='about'),
    path('delete_/<int:pk>',delete_,name='delete_'),
    path('restore/<int:pk>',restore,name='restore'),
]