from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=20)
    course = models.CharField(max_length=30)
    simage = models.ImageField(upload_to='uploads/',default='Default.jpg',blank=True,null=True)



#static
    #css
        # no_files3
    #images
        #default
        #uploads