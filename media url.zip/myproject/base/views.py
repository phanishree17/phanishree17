from django.shortcuts import render
from .models import Student
# Create your views here.
def home(request):
    a = Student.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')
        course = request.POST.get('course')
        simage = request.FILES.get('pic')
        Student.objects.create(
            name = name,
            course = course,
            simage = simage if simage else 'Default.jpg'
        )
    return render(request,'home.html',{'data':a})

#login
#logout
#register
#profile
#rest pass
#forget pass
#update profile
#update pass
#these topic should be implemented in flight management system