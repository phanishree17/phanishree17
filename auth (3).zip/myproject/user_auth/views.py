
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required


# Create your views here.
def login_(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username,password)
        u = authenticate(username=username,password=password)
        print(u) #None #admin
        if u:
            login(request,u)
            return redirect('home')
        else:
            return render(request,'login_.html',{'status':'entered username or password is wrong'})
    return render(request,'login_.html')


def register(request):
    if request.method == 'POST':
        a = request.POST['fname']
        last_name = request.POST['lname']
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['password']
        # print(a,last_name,email,username,password)
        try:
            u = User.objects.get(username=username)
            return render(request,'register.html',{'status':'username already exist,create the different username....' })
        except:
            u = User.objects.create(
                first_name  = a,  #name from the database = variable where you have fletched the data
                last_name = last_name,
                email = email,
                username = username,
                # password = password
            )
            u.set_password(password)
            u.save()

    return render(request,'register.html')

@login_required(login_url='login_')
def profile(request):
    return render(request,'profile.html')

@login_required(login_url='login_')
def logout_(request):
    logout(request)
    return redirect('login_')


def rest_pass(request):
    return render(request,'rest_pass.html')