from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='login_')
def home(request):
    return render(request,'home.html')

@login_required(login_url='login_')
def add(request):
    return render(request,'add.html')

@login_required(login_url='login_')
def complete(request):
    return render(request,'complete.html')

@login_required(login_url='login_')
def trash(request):
    return render(request,'trash.html')

@login_required(login_url='login_')
def about(request):
    return render(request,'about.html')

# What is Authentication?
# verifying who is the user
# django will check the users username and password

# django.contrib.auth
# 'django.contrib.sessions',
# ther are responsible for the authentication sytem

